package br.edu.ifpb.restdelivery.dao.impl;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Query;


import br.edu.ifpb.restdelivery.entities.Address;

public class AddressDAO extends ImplGenericDAO<Address, Long> implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@SuppressWarnings("unchecked")
	public List<String> loadingCity(int idState) {
		Query query = (Query) em
				.createNativeQuery("Select fd.city_name from fd_Cidades fd where fd.id_state = " + idState);

		return query.getResultList();
	}

}
