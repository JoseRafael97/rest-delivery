package br.edu.ifpb.restdelivery.dao.impl;


import java.io.Serializable;

import br.edu.ifpb.restdelivery.entities.Category;



public class CategoryDAO  extends ImplGenericDAO<Category, Long> implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2050279174248805560L;


	

}
