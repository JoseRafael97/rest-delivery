package br.edu.ifpb.restdelivery.dao;


import javax.inject.Inject;
import javax.persistence.EntityManager;


public abstract class DAO{

	@Inject
	protected EntityManager em;

	
}