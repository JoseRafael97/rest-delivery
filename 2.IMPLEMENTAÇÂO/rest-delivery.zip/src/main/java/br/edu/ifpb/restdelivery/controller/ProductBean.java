package br.edu.ifpb.restdelivery.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.UploadedFile;

import br.edu.ifpb.restdelivery.entities.Product;
import br.edu.ifpb.restdelivery.enumerations.CategoryType;
import br.edu.ifpb.restdelivery.exceptions.RestDeliveryException;
import br.edu.ifpb.restdelivery.services.impl.ProductService;

@Named
@ViewScoped
public class ProductBean extends AbstractBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Inject
	private ProductService service;

	private Product product;

	private String destination = "restDelivery";

	private UploadedFile file;

	@PostConstruct
	public void preRenderView() {
		if (product == null) {
			product = new Product();
		}
	}

	public String save() {

		try {
			service.save(product);

			if (product.getId() == null) {
				reportSuccessMensage("Item de menu salvo!");

			} else {
				reportSuccessMensage("Item de menu alterado!");
				return "product?faces-redirect=true";

			}
			product = new Product();
		} catch (RestDeliveryException e) {
			reportErroMensage(e.getMessage());
			e.printStackTrace();
		}
		return destination;
	}
	
	

	public void handleFileUpload(FileUploadEvent event) {

		FacesMessage msg = new FacesMessage("Success! ", event.getFile().getFileName() + " is uploaded.");
		FacesContext.getCurrentInstance().addMessage(null, msg);
		try {
			String home = System.getProperty("user.home");

			File diretorio = new File(home, destination);

			if (!diretorio.exists()) {
				diretorio.mkdirs();
			} else {
				System.out.println("Diretório já existente");
			}

			byte[] conteudo = event.getFile().getContents();
			FileOutputStream fos = new FileOutputStream(home + "/" + "restDelivery/" + event.getFile().getFileName());
			fos.write(conteudo);
			fos.close();

			product.setPathFile(event.getFile().getFileName());

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public CategoryType[] getCategories() {
		return CategoryType.values();
	}

	public UploadedFile getFile() {
		return file;
	}

	public void setFile(UploadedFile file) {
		this.file = file;
	}

}
