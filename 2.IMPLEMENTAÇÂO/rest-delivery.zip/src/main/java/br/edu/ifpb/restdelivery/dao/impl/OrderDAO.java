package br.edu.ifpb.restdelivery.dao.impl;

import java.io.Serializable;

import br.edu.ifpb.restdelivery.entities.Order;

public class OrderDAO extends ImplGenericDAO<Order, Long> implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	

}
