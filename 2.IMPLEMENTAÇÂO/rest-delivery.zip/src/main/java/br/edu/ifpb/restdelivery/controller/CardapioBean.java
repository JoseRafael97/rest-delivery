package br.edu.ifpb.restdelivery.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.event.AjaxBehaviorEvent;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import br.edu.ifpb.restdelivery.entities.ItemMenu;
import br.edu.ifpb.restdelivery.entities.Menu;
import br.edu.ifpb.restdelivery.enumerations.OptionFind;
import br.edu.ifpb.restdelivery.exceptions.RestDeliveryException;
import br.edu.ifpb.restdelivery.services.impl.MenuService;
import br.edu.ifpb.restdelivery.util.OrdenedBigPriceComparable;
import br.edu.ifpb.restdelivery.util.OrdenedLitlePriceComparator;
import br.edu.ifpb.restdelivery.util.Tools;

@Named
@ViewScoped
public class CardapioBean extends AbstractBean {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Inject
	private MenuService menuService;

	private String category;

	private String optionFilter;

	private List<ItemMenu> itemMenus;

	@PostConstruct
	public void init() {
		itemMenus = new ArrayList<>();
		category = "";
	}

	public List<ItemMenu> getItemMenus() throws RestDeliveryException {

		if (optionFilter == null || optionFilter.equals("Selecione para filtrar")) {

			Menu m = menuService.selectMenuActive();
			itemMenus.clear();

			for (ItemMenu item : m.getMenuItens()) {
				if (item.getProduct().getCategory().getNome().equalsIgnoreCase(category)) {
					itemMenus.add(item);

				} else if (category == null || category.isEmpty()) {
					itemMenus.add(item);
				}
			}

			if (itemMenus.size() > 0) {
				Tools.loadImgItens(itemMenus);
			}

		}
		return itemMenus;
	}

	public void filterOptions(final AjaxBehaviorEvent event) throws RestDeliveryException {

		Menu m = menuService.selectMenuActive();
		itemMenus.clear();
		itemMenus = m.getMenuItens();

		if (OptionFind.MAIOP.getNome().equalsIgnoreCase(optionFilter)) {
			Collections.sort(itemMenus, new OrdenedBigPriceComparable());
		
		}else if(OptionFind.MENP.getNome().equals(optionFilter)){
			Collections.sort(itemMenus, new OrdenedLitlePriceComparator());
		
		}else if(OptionFind.MAISV.getNome().equals(optionFilter)){
			
		}else if(OptionFind.RECAD.getNome().equals(optionFilter)){}
		

		if (itemMenus.size() > 0) {
			Tools.loadImgItens(itemMenus);
		}
		
		

	}

	public void filterCategory(final AjaxBehaviorEvent event) throws RestDeliveryException {
		this.getItemMenus();
	}

	public void setItemMenus(List<ItemMenu> itemMenus) {
		this.itemMenus = itemMenus;
	}

	public String getCategory() {
		return category;

	}

	public void setCategory(String category) {
		this.category = category;
	}

	public OptionFind[] getOptionFind() {
		return OptionFind.values();
	}

	public String getOptionFilter() {
		return optionFilter;
	}

	public void setOptionFilter(String optionFilter) {
		this.optionFilter = optionFilter;
	}

}
