package br.edu.ifpb.restdelivery.util;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.util.List;

import javax.faces.context.FacesContext;

import br.edu.ifpb.restdelivery.entities.ItemMenu;
import br.edu.ifpb.restdelivery.entities.ItemProduct;
import br.edu.ifpb.restdelivery.entities.Product;
import br.edu.ifpb.restdelivery.enumerations.StateNames;

public class Tools {

	public static void copy(String filePath, String fileName) throws IOException {
		FileInputStream origem;
		FileOutputStream destino;
		FileChannel fcOrigem;
		FileChannel fcDestino;
		String home = System.getProperty("user.home");
		String destiny = FacesContext.getCurrentInstance().getExternalContext().getRealPath("resources/images/");

		origem = new FileInputStream(home + "/restDelivery/" + filePath);
		destino = new FileOutputStream(destiny + "/" + fileName);

		fcOrigem = origem.getChannel();
		fcDestino = destino.getChannel();
		fcOrigem.transferTo(0, fcOrigem.size(), fcDestino);

		origem.close();
		destino.close();
	}

	public static void loadImgProduct(List<Product> products) {
		for (Product p : products) {
			try {
					Tools.copy(p.getPathFile(), p.getPathFile());
					
				
	
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public static void loadImgItens(List<ItemMenu> products) {
		for (ItemMenu p : products) {
			try {
				if (p.getProduct().getPathFile() != null || !p.getProduct().getPathFile().isEmpty()) {
					Tools.copy(p.getProduct().getPathFile(), p.getProduct().getPathFile());
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public static Float priceItem(Integer quant, Float price) {
		float value = quant * price;
		return value;
	}

	public static Float priceAllItens(List<ItemProduct> itens) {
		float value = 0;
		for (int i = 0; i < itens.size(); i++) {
			value += itens.get(i).getPrice();
		}
		return value;
	}
	
	public static int getIdState(String name){
		StateNames[] values = StateNames.values();
		for(int i = 0; i< values.length ; i++){
			String n = values[i].getNome();
			if (name.equalsIgnoreCase(n)) {
				return values[i].getId();
			}
		}
		
		return 0;
	}
	
	
		
	

}



