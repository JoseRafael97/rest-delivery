package br.edu.ifpb.restdelivery.util;

import java.util.Comparator;

import br.edu.ifpb.restdelivery.entities.ItemMenu;

public class OrdenedBigPriceComparable implements Comparator<ItemMenu>{

	@Override
	public int compare(ItemMenu o1, ItemMenu o2) {
		if(o1.getPrice() > o2.getPrice()){
			return -1;
			
		}else if(o1.getPrice() < o1.getPrice()){
			return +1;
			
		}else{
			return 0;
		}
	}

	
	

}
