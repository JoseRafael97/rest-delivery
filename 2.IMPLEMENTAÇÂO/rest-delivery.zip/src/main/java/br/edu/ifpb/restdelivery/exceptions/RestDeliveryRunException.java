package br.edu.ifpb.restdelivery.exceptions;

public class RestDeliveryRunException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public RestDeliveryRunException(String mensagem) {
		super(mensagem);
	}

}
