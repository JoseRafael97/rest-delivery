package br.edu.ifpb.restdelivery.util.jsf;

import javax.faces.context.ExceptionHandler;
import javax.faces.context.ExceptionHandlerFactory;

public class JsfExceptionHandlerFactory extends ExceptionHandlerFactory{

	
	private ExceptionHandlerFactory handlerFactory;
	
	public JsfExceptionHandlerFactory(ExceptionHandlerFactory exceptionHandlerFactory) {
		this.handlerFactory = exceptionHandlerFactory;
	}
	
	@Override
	public ExceptionHandler getExceptionHandler() {
		return new JsfExceptionHandler(handlerFactory.getExceptionHandler());
	}

}
