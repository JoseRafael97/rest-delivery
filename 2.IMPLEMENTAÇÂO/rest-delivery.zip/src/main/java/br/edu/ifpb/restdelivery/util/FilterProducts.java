package br.edu.ifpb.restdelivery.util;

import java.io.Serializable;

public class FilterProducts implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String description;
	
	private int first;
	private int amount;
	
	private boolean ascendent;
	
	private String propetyOrdened;
	
	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	public int getFirst() {
		return first;
	}
	
	public void setFirst(int first) {
		this.first = first;
	}
	
	public int getAmount() {
		return amount;
	}
	
	public void setAmount(int amount) {
		this.amount = amount;
	}

	public boolean isAscendent() {
		return ascendent;
	}

	public void setAscendent(boolean ascendent) {
		this.ascendent = ascendent;
	}

	public String getPropetyOrdened() {
		return propetyOrdened;
	}

	public void setPropetyOrdened(String propetyOrdened) {
		this.propetyOrdened = propetyOrdened;
	}
	
	
	

}
