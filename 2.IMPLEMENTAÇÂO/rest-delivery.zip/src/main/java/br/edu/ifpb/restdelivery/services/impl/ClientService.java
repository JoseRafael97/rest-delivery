package br.edu.ifpb.restdelivery.services.impl;


import javax.inject.Inject;

import br.edu.ifpb.restdelivery.dao.impl.ClientDAO;
import br.edu.ifpb.restdelivery.entities.Address;
import br.edu.ifpb.restdelivery.entities.Client;
import br.edu.ifpb.restdelivery.entities.Order;
import br.edu.ifpb.restdelivery.exceptions.RestDeliveryException;
import br.edu.ifpb.restdelivery.util.Validator;

public class ClientService extends GenericService<Client, Long> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Inject
	public ClientService(ClientDAO clientDAO) {
		this.dao = clientDAO;
	}

	public Client findByLogin(String login) throws RestDeliveryException {

		for (Client c : listAll()) {
			if (c.getLogin().equals(login)) {
				return c;
			}
		}

		throw new RestDeliveryException("Cliente não encontrado!");
	}

	public void finallybuy(Order order, Client client) throws RestDeliveryException {

		Address address = client.getAddresses().get(client.getAddresses().size() - 1);

		if (!address.getNumber().equals(order.getDelivery().getAddress().getNumber())
				&& !address.getCity().equals(order.getDelivery().getAddress().getCity())) {

			order.getDelivery().getAddress().setId(null);
			client.getAddresses().add(order.getDelivery().getAddress());

		}

		Validator.validateBuy(client);
		client.getOrders().add(order);

		this.save(client);

	}

}
