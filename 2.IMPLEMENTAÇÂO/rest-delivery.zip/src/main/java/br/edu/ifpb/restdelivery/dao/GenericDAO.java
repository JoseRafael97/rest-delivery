package br.edu.ifpb.restdelivery.dao;

import java.io.Serializable;
import java.util.List;



public interface GenericDAO<T, K extends Serializable> {
	/**
	 * Cria um novo objeto
	 * 
	 * @param object
	 */
	public void add(T object);

	/**
	 * Remove um objeto do banco
	 * 
	 * @param key
	 *            identificador do objeto
	 */
	public void remove(T object);

	/**
	 * Atualiza informações do objeto
	 * 
	 * @param key
	 *            idetificador do objeto
	 * @param object
	 *            objeto alterado
	 */
	
	public void update(T object);

	/**
	 * Busca no banco o objeto com o identificador passado.
	 * 
	 * @param key
	 *            idetificador do objeto.
	 * @return O objeto correpondente a chave idetificadora.
	 */
	
	public T find(K key);

	/**
	 * Busca todos os objetos do tipo existente no Banco.
	 * 
	 * @return um lista com todos os objetos.
	 */
	public List<T> findAll();

}
