package br.edu.ifpb.restdelivery.services.impl;


import java.util.List;

import javax.inject.Inject;

import br.edu.ifpb.restdelivery.dao.impl.ProductDAO;
import br.edu.ifpb.restdelivery.entities.Product;
import br.edu.ifpb.restdelivery.util.FilterProducts;

public class ProductService extends GenericService<Product, Long>  {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Inject
	public ProductService(ProductDAO productDAO) {
		this.dao = productDAO;
	}
	
	public int countFilter(FilterProducts filter){
		return ((ProductDAO)this.dao).countFilter(filter);
	}
 
	public List<Product> filterProduct(FilterProducts filterProducts) {
		return ((ProductDAO)this.dao).filterProduct(filterProducts);
	}
}
