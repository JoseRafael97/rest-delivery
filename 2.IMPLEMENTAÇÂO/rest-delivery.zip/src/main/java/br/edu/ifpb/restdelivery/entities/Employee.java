package br.edu.ifpb.restdelivery.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.br.CPF;

@Entity
@Table
@PrimaryKeyJoinColumn(name = "user_id")
public class Employee extends User implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String name;

	private String cpf;
	private String ctps;

	private String tellphone;
	private char sexo;
	private Address address;

	public Employee() {

	}

	public Employee(String login, String password, String name, String email, String cpf, String ctps, String telefone, char sexo) {
		super(login, password, email);
		this.name = name;
		this.cpf = cpf;
		this.ctps = ctps;
		this.tellphone = telefone;
		this.sexo = sexo;
	}

	
	@Column(name = "tellphone")
	public String getTellphone() {
		return tellphone;
	}

	public void setTellphone(String tellphone) {
		this.tellphone = tellphone;
	}

	@OneToOne
	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	@NotNull @NotEmpty
	@Column(name = "name", nullable = false)
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@CPF
	@Column(name = "cpf", nullable = false)
	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	
	@NotNull @NotEmpty
	@Column(name = "ctps")
	public String getCtps() {
		return ctps;
	}

	public void setCtps(String ctps) {
		this.ctps = ctps;
	}

	@NotNull
	@Column(name = "sexo", nullable = false)
	public char getSexo() {
		return sexo;
	}

	public void setSexo(char sexo) {
		this.sexo = sexo;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((cpf == null) ? 0 : cpf.hashCode());
		result = prime * result + ((ctps == null) ? 0 : ctps.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + sexo;
		result = prime * result + ((tellphone == null) ? 0 : tellphone.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (cpf == null) {
			if (other.cpf != null)
				return false;
		} else if (!cpf.equals(other.cpf))
			return false;
		if (ctps == null) {
			if (other.ctps != null)
				return false;
		} else if (!ctps.equals(other.ctps))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (sexo != other.sexo)
			return false;
		if (tellphone == null) {
			if (other.tellphone != null)
				return false;
		} else if (!tellphone.equals(other.tellphone))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Employee [name=" + name + ", cpf=" + cpf + ", ctps=" + ctps + ", telefone=" + tellphone + ", sexo="
				+ sexo + "]";
	}

}
