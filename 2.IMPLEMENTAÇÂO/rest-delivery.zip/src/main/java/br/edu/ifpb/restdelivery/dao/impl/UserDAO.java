package br.edu.ifpb.restdelivery.dao.impl;

import java.io.Serializable;

import br.edu.ifpb.restdelivery.entities.User;

public class UserDAO extends ImplGenericDAO<User, Long> implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	

}
