package br.edu.ifpb.restdelivery.services.impl;

import javax.inject.Inject;

import br.edu.ifpb.restdelivery.dao.impl.CategoryDAO;
import br.edu.ifpb.restdelivery.entities.Category;

public class CategoryService extends GenericService<Category, Long>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Inject
	public CategoryService(CategoryDAO categoryDao) {
		this.dao = categoryDao;
	}

}
