package br.edu.ifpb.restdelivery.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import br.edu.ifpb.restdelivery.entities.ItemMenu;
import br.edu.ifpb.restdelivery.entities.Menu;
import br.edu.ifpb.restdelivery.exceptions.RestDeliveryException;
import br.edu.ifpb.restdelivery.services.impl.MenuService;

@Named
@ViewScoped
public class MenuBean extends AbstractBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Inject
	private MenuService menuService;

	private Menu menu;

	private ItemMenu item;

	private List<ItemMenu> itensSelected;

	public void preRenderView() {
		if (menu == null) {
			menu = new Menu();
		}

		if (item == null) {
			item = new ItemMenu();
		}

		if (itensSelected == null) {
			itensSelected = new ArrayList<>();
		}

	}

	public String save() {
		try {
			menu.setMenuItens(itensSelected);

			if (menu.isAtivo()) {
				if (menuService.selectMenuActive() == null ) {
					menuService.save(menu);

				} else {
					reportErroMensage("Já existe um cardápio ativo");
					return null;
				}
			} else {
				menuService.save(menu);
			}

			if (menu.getId() == null) {
				reportSuccessMensage("Novo cardápio salvo!");

			} else {
				reportSuccessMensage("Menu alterado!");
				return "menu?faces-redirect=true";
			}

			itensSelected.clear();
			menu = new Menu();
			item = new ItemMenu();
		} catch (RestDeliveryException e) {
			reportErroMensage(e.getMessage());
			e.printStackTrace();
		}
		return null;
	}

	public void removeItem() {
		try {
			menu.getMenuItens().remove(item);
			menuService.save(menu);
			reportSuccessMensage("Item do cardápio removido!");
		} catch (RestDeliveryException e) {
			reportErroMensage(e.getMessage());
			e.printStackTrace();
		}
	}

	public boolean isRendere() {
		return menu.getMenuItens() == null;
	}

	public boolean isRendereEdit() {
		if (menu.getMenuItens() != null) {
			itensSelected = menu.getMenuItens();
		}
		return menu.getMenuItens() != null;
	}

	public void addItemMenu() {
		if (itensSelected != null && itensSelected.size() > 0) {
			for (int i = 0; i < itensSelected.size(); i++) {
				if (itensSelected.get(i).getProduct().getId() == item.getProduct().getId()) {
					reportErroMensage("Item do cardápio já adicionado anteriomente");
					return;
				}
			}

		}
		itensSelected.add(item);
		item = new ItemMenu();

	}

	public void addMessage() {
		String summary = menu.isAtivo() ? "Checked" : "Unchecked";
		reportSuccessMensage(summary);
	}

	public Menu getMenu() {
		return menu;
	}

	public void setMenu(Menu menu) {
		this.menu = menu;
	}

	public ItemMenu getItem() {
		return item;
	}

	public void setItem(ItemMenu item) {
		this.item = item;
	}

	public List<ItemMenu> getItensSelected() {
		return itensSelected;
	}

	public void setItensSelected(List<ItemMenu> itensSelected) {
		this.itensSelected = itensSelected;
	}

}
