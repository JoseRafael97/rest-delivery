package br.edu.ifpb.restdelivery.services.impl;

import javax.inject.Inject;

import br.edu.ifpb.restdelivery.dao.impl.MenuDAO;
import br.edu.ifpb.restdelivery.entities.Menu;
import br.edu.ifpb.restdelivery.exceptions.RestDeliveryException;

public class MenuService extends GenericService<Menu, Long>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Inject
	public MenuService(MenuDAO menuDAO) {
		this.dao = menuDAO;
	}
	
	
	public Menu selectMenuActive() throws RestDeliveryException{
		
		for(Menu menu : listAll()){
			if(menu.isAtivo()){
				return menu;
			}
		}
		
		return null;
	}
	
	public void activeMenu(Menu menu) throws RestDeliveryException{
		for(Menu m : listAll()){
			if(m.isAtivo()){
				throw new RestDeliveryException("Já existe um menu ativo!");
			}
		}
		
		menu.setAtivo(true);
		save(menu);
	}
	

}
