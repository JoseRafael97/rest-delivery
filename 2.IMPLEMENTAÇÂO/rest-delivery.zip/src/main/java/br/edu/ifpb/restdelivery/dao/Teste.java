package br.edu.ifpb.restdelivery.dao;



import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import br.edu.ifpb.restdelivery.entities.Address;
import br.edu.ifpb.restdelivery.entities.Client;





public class Teste {
	public static void main(String[] args) {

		EntityManagerFactory emf = null;
		EntityManager em = null;
		EntityTransaction tx = null;

		emf = Persistence.createEntityManagerFactory("post");
		em = emf.createEntityManager();

		tx = em.getTransaction();
		tx.begin();

		Client client = new Client("client123","123","Cliente","013.873.072-58","jose.rafael.feitosa@gmail.com",'M');
		
		
		//Address address = new Address("7 de setembro","Centro","Humaitá", "AM","69800-000",12);
		
		List<Address> addresses = new ArrayList<>();
		//addresses.add(address);
		
		client.setAddresses(addresses);
		
	/*	ItemProduct it = new ItemProduct();
		ItemMenu item1 = em.find(ItemMenu.class, 1l);
		ItemMenu item2 = em.find(ItemMenu.class, 2l);
		
		it.setItemMenu(item1);
		it.setAmount(1);
		it.setPrice(item1.getPrice());
		
		ItemProduct it2 = new ItemProduct();
		it2.setItemMenu(item2);
		it2.setAmount(1);
		it2.setPrice(item2.getPrice());
		
		Payment payment = new Payment();
		payment.setData(new Date());
		payment.setProprety("Rafael Feitosa");
		payment.setType(PaymentType.DEBIT);
		
		Order order = new Order();
		order.setData(new Date());
		order.setPayment(payment);
		
		List<ItemProduct> itemProducts = new ArrayList<>();
		itemProducts.add(it);
		itemProducts.add(it2);
		
		order.setItemProducts(itemProducts);
		order.setTotalprice(2222f);
		
		
		Client client = em.find(Client.class, 1l);
		
		order.setAddressDelivery(client.getAddresses().get(0));
		
		List<Order> orders = new ArrayList<>();
		orders.add(order);
		
		client.setOrders(orders);*/
				
		em.merge(client);
		tx.commit();

		if (em != null) {
			em.close();
		}
		if (emf != null) {
			emf.close();
		}

	}
}
