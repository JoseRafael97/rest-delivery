package br.edu.ifpb.restdelivery.dao.impl;

import java.io.Serializable;
import java.lang.reflect.ParameterizedType;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.Query;

import org.hibernate.Session;

import br.edu.ifpb.restdelivery.dao.GenericDAO;

/**
 * @author rafaelfeitosa
 *
 * @param <T>
 *            Tipo da classe
 * @param <K>
 *            Tipo do identificador
 */
public class ImplGenericDAO<T, K extends Serializable> implements GenericDAO<T, K> {

	@Inject
	protected EntityManager em;

	private Class<T> persistentClass;

	@SuppressWarnings("unchecked")
	public ImplGenericDAO() {
		this.persistentClass = (Class<T>) ((ParameterizedType) getClass().getGenericSuperclass())
				.getActualTypeArguments()[0];

	}

	public void add(T object) {
		try {
			em.merge(object);
		} catch (PersistenceException pe) {
			pe.printStackTrace();
		}
	}

	public void remove(T object) {
		em.remove(em.merge(object));
	}

	public void update(T object) {
		em.merge(object);
	}

	@SuppressWarnings("unchecked")
	public List<T> findAll() {
		Query query = em.createQuery("select t from " + persistentClass.getName() + " t");
		return query.getResultList();
	}

	@Override
	public T find(K key) {
		T instance = em.find(persistentClass, key);
		return instance;
	}

	protected EntityManager getEntityManager() {
		return em;
	}

	protected Session getSession() {
		return em.unwrap(Session.class);
	}

}
