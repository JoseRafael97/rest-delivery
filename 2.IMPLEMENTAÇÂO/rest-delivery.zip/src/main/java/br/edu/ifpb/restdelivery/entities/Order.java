package br.edu.ifpb.restdelivery.entities;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name= "tab_order")
public class Order implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long id;
	private Date data;
	private float totalprice;
	private Payment payment;
	private List<ItemProduct> itemProducts;
	private Delivery delivery;

	public Order() {

	}

	public Order(Long id, Date data, float totalprice) {
		this.id = id;
		this.data = data;
		this.totalprice = totalprice;
	}

	public Order(Date data, float totalprice) {
		this.data = data;
		this.totalprice = totalprice;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	@OneToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "order_item_product", joinColumns = @JoinColumn(name = "id_order"),
	inverseJoinColumns = @JoinColumn(name = "id_item_product"))
	public List<ItemProduct> getItemProducts() {
		return itemProducts;
	}

	public void setItemProducts(List<ItemProduct> itemProducts) {
		this.itemProducts = itemProducts;
	}
	
	@OneToOne(cascade = CascadeType.ALL)
	public Payment getPayment() {
		return payment;
	}

	public void setPayment(Payment payment) {
		this.payment = payment;
	}

	@OneToOne(cascade = CascadeType.ALL)
	public Delivery getDelivery() {
		return delivery;
	}

	public void setDelivery(Delivery delivery) {
		this.delivery = delivery;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "date")
	public Date getData() {
		return data;
	}

	public void setData(Date data) {
		this.data = data;
	}

	@Column(name = "totalprice")
	public float getTotalprice() {
		return totalprice;
	}

	public void setTotalprice(float totalprice) {
		this.totalprice = totalprice;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((data == null) ? 0 : data.hashCode());
		result = prime * result + ((delivery == null) ? 0 : delivery.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((itemProducts == null) ? 0 : itemProducts.hashCode());
		result = prime * result + ((payment == null) ? 0 : payment.hashCode());
		result = prime * result + Float.floatToIntBits(totalprice);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Order other = (Order) obj;
		if (data == null) {
			if (other.data != null) {
				return false;
			}
		} else if (!data.equals(other.data)) {
			return false;
		}
		if (delivery == null) {
			if (other.delivery != null) {
				return false;
			}
		} else if (!delivery.equals(other.delivery)) {
			return false;
		}
		if (id == null) {
			if (other.id != null) {
				return false;
			}
		} else if (!id.equals(other.id)) {
			return false;
		}
		if (itemProducts == null) {
			if (other.itemProducts != null) {
				return false;
			}
		} else if (!itemProducts.equals(other.itemProducts)) {
			return false;
		}
		if (payment == null) {
			if (other.payment != null) {
				return false;
			}
		} else if (!payment.equals(other.payment)) {
			return false;
		}
		if (Float.floatToIntBits(totalprice) != Float.floatToIntBits(other.totalprice)) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "Order [id=" + id + ", data=" + data + ", totalprice=" + totalprice + ", payment=" + payment
				+ ", itemProducts=" + itemProducts + ", delivery=" + delivery + "]";
	}

	

}
