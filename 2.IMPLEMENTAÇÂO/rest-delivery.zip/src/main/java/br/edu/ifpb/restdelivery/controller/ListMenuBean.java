package br.edu.ifpb.restdelivery.controller;

import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;
import br.edu.ifpb.restdelivery.entities.Menu;
import br.edu.ifpb.restdelivery.exceptions.RestDeliveryException;
import br.edu.ifpb.restdelivery.services.impl.MenuService;
import br.edu.ifpb.restdelivery.util.Tools;

@Named
@RequestScoped
public class ListMenuBean extends AbstractBean {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Menu menu;

	private List<Menu> menus;
	

	@Inject
	private MenuService menuService;
	
	public Menu getMenu() {
		return menu;
	}
	
	public void remove() {
		try {
			menuService.remove(menu);
			menus.remove(menu);
			reportSuccessMensage("Cardápio removido!");

		} catch (RestDeliveryException e) {
			reportErroMensage(e.getMessage());
			e.printStackTrace();
		}
	}

	
	public void setMenu(Menu menu) {
		this.menu = menu;
	}

	public List<Menu> getMenus() {
		if (menus == null) {
			menus = (List<Menu>) menuService.listAll();
			for(Menu m : menus){
				Tools.loadImgItens(m.getMenuItens());
			}
		}
		return menus;

	}

	public void setMenus(List<Menu> menus) {
		this.menus = menus;
	}

}
