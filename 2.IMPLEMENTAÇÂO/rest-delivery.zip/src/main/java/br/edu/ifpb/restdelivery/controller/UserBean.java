package br.edu.ifpb.restdelivery.controller;

import java.util.List;

import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import javax.inject.Named;

import br.edu.ifpb.restdelivery.entities.Client;
import br.edu.ifpb.restdelivery.entities.User;
import br.edu.ifpb.restdelivery.services.impl.UserService;

@Named
@SessionScoped
public class UserBean extends AbstractBean {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Inject
	private UserService userService;

	private String login;
	private String password;

	public String loginUser() {
		List<User> users = userService.listAll();

		for (User u : users) {
			if (u.getLogin().equals(login) || u.getEmail().equals(login)) {
				if (u.getPassword().equals(password)) {
					if (u instanceof Client) {

						return "main_page?faces-redirect=true";

					} else {
						return "main_page_emp?faces-redirect=true";

					}
				}
			}
		}

		reportErroMensage("Login Invalido");
		return login;
	}

	public UserService getUserService() {
		return userService;
	}

	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
