package br.edu.ifpb.restdelivery.services.impl;

import javax.inject.Inject;

import br.edu.ifpb.restdelivery.dao.impl.EmployeeDAO;
import br.edu.ifpb.restdelivery.entities.Employee;

public class EmployeeService extends GenericService<Employee, Long>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Inject
	public EmployeeService(EmployeeDAO employeeDAO) {
		this.dao = employeeDAO;
	}

}
