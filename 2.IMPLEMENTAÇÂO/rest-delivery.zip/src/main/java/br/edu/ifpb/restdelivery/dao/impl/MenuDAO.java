package br.edu.ifpb.restdelivery.dao.impl;

import java.io.Serializable;

import br.edu.ifpb.restdelivery.entities.Menu;

public class MenuDAO extends ImplGenericDAO<Menu, Long> implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
