package br.edu.ifpb.restdelivery.controller;

import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;

import br.edu.ifpb.restdelivery.entities.Product;
import br.edu.ifpb.restdelivery.exceptions.RestDeliveryException;
import br.edu.ifpb.restdelivery.services.impl.ProductService;
import br.edu.ifpb.restdelivery.util.FilterProducts;
import br.edu.ifpb.restdelivery.util.Tools;

@Named
@RequestScoped
public class ListProductBean extends AbstractBean {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Product product;

	private LazyDataModel<Product> model;

	private FilterProducts filter = new FilterProducts();

	private List<Product> products;

	@Inject
	private ProductService service;

	@PostConstruct
	void init() {
		product = new Product();

	}

	public ListProductBean() {
		model = new LazyDataModel<Product>() {

			private static final long serialVersionUID = 1L;

			@Override
			public List<Product> load(int first, int pageSize, String sortField, SortOrder sortOrder,
					Map<String, Object> filters) {

				filter.setFirst(first);
				filter.setAmount(pageSize);
				filter.setAscendent(SortOrder.ASCENDING.equals(sortOrder));
				filter.setPropetyOrdened(sortField);

				setRowCount(service.countFilter(filter));
				Tools.loadImgProduct(service.filterProduct(filter));
				return service.filterProduct(filter);
			}

		};
	}

	public void remove(Product p) {
		try {
			service.remove(p);
			products.remove(p);
			reportSuccessMensage("Item de menu removido!");
		} catch (RestDeliveryException e) {
			reportErroMensage(e.getMessage());
			e.printStackTrace();
		}
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public List<Product> getProducts() {
		if (products == null) {
			products = (List<Product>) service.listAll();
			Tools.loadImgProduct(products);
		}
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}

	public LazyDataModel<Product> getModel() {
		return model;
	}

}
