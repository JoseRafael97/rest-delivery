package br.edu.ifpb.restdelivery.exceptions;

public class ItemInesxistenteException extends RestDeliveryException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ItemInesxistenteException(String mensagem) {
		super(mensagem);
	}

}
