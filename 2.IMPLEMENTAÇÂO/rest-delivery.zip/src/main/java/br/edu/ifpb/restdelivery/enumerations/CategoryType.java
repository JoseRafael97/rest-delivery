package br.edu.ifpb.restdelivery.enumerations;

public enum CategoryType {
	DESSERTS("Sobremesas"),
	SNACKS("Lanches"),
	PIZZA("Pizza"),
	SALTED("Salgados"),
	DRINKS("Bebidas"),
	SALADS("Saladas"),
	LUNCHES("Almoços"),
	COMBINED("Combinados");

	
	String nome;
	
	private CategoryType(String atributo) {
		this.nome = atributo;
		
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
}
