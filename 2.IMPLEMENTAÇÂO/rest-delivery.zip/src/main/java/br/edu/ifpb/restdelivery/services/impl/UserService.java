package br.edu.ifpb.restdelivery.services.impl;

import java.util.List;

import javax.inject.Inject;

import br.edu.ifpb.restdelivery.dao.impl.UserDAO;
import br.edu.ifpb.restdelivery.entities.User;
import br.edu.ifpb.restdelivery.exceptions.RestDeliveryException;

public class UserService extends GenericService<User, Long>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Inject
	public UserService(UserDAO userDAO) {
		this.dao = userDAO;
	}
	
	
	public User login(String login, String password) throws RestDeliveryException{
		List<User> users = listAll();
		
		for(User user : users){
			if(user.getLogin().equals(login) &&  user.equals(password)){
				return user;
			}
		}
		
		throw new RestDeliveryException("Login invalido");
	}

}
