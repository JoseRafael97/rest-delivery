package br.edu.ifpb.restdelivery.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.enterprise.context.SessionScoped;
import javax.faces.event.AjaxBehaviorEvent;
import javax.inject.Inject;
import javax.inject.Named;
import org.primefaces.event.FlowEvent;
import org.primefaces.event.RowEditEvent;

import br.edu.ifpb.restdelivery.entities.Address;
import br.edu.ifpb.restdelivery.entities.Client;
import br.edu.ifpb.restdelivery.entities.Delivery;
import br.edu.ifpb.restdelivery.entities.ItemMenu;
import br.edu.ifpb.restdelivery.entities.ItemProduct;
import br.edu.ifpb.restdelivery.entities.Order;
import br.edu.ifpb.restdelivery.entities.Payment;
import br.edu.ifpb.restdelivery.enumerations.PaymentType;
import br.edu.ifpb.restdelivery.enumerations.StateNames;
import br.edu.ifpb.restdelivery.exceptions.RestDeliveryException;
import br.edu.ifpb.restdelivery.services.impl.AddressService;
import br.edu.ifpb.restdelivery.services.impl.ClientService;
import br.edu.ifpb.restdelivery.util.Tools;
import br.edu.ifpb.restdelivery.util.Validator;

@Named
@SessionScoped
public class FinallyOrderBean extends AbstractBean {

	private static final long serialVersionUID = 1L;

	private Client client;
	private Order order;
	private List<ItemProduct> itemProducts;
	private ItemProduct itemProduct;
	private ItemMenu itemMenu;
	private String loginClient;
	private float priceAll;
	private List<String> listCity;

	@Inject
	private ClientService clientService;

	@Inject
	private AddressService addressService;

	public void preRenderView() {
		try {
			if (client == null) {
				client = clientService.findByLogin(loginClient);
				order.getDelivery().setAddress(client.getAddresses().get(client.getAddresses().size() - 1));
			}
		} catch (RestDeliveryException e) {
			e.printStackTrace();
		}

	}

	@PostConstruct
	void init() {
		itemProduct = new ItemProduct();
		itemProducts = new ArrayList<>();

		if (order == null) {
			order = new Order();
		}

		if (order.getPayment() == null) {
			order.setPayment(new Payment());
		}

		if (order.getDelivery() == null) {
			order.setDelivery(new Delivery());
		}
	}

	public void subjectSelectionChanged(final AjaxBehaviorEvent event) {
		listCity = addressService.loadingCity(Tools.getIdState(order.getDelivery().getAddress().getState()));
	}

	public List<String> getLoadingCity() {
		if (listCity == null) {
			listCity = addressService.loadingCity(Tools.getIdState(order.getDelivery().getAddress().getState()));
		}
		return listCity;
	}

	public StateNames[] getStateName() {
		StateNames[] states = StateNames.values();
		return states;
	}

	public void onRowEdit(RowEditEvent event) {
		ItemProduct item = (ItemProduct) event.getObject();
		for (ItemProduct ip : itemProducts) {
			if (ip.getId() == item.getId()) {
				ip.setAmount(item.getAmount());
				ip.setPrice(Tools.priceItem(item.getAmount(), item.getItemMenu().getPrice()));
			}
		}
		reportSuccessMensage("Editado com sucesso!");
	}

	public void onRowCancel(RowEditEvent event) {
		reportSuccessMensage("Editar cancelado!");
	}

	public String cancelOrder() {
		itemProducts.clear();
		return "main_page?faces-redirect=true";

	}

	public void saveItemProduct() {
		if (itemProduct.getAmount() < 1) {
			reportErroMensage("Quantidade inválida");
			return;
		}

		if (itemProducts != null && itemProducts.size() > 0) {
			for (int i = 0; i < itemProducts.size(); i++) {
				if (itemProducts.get(i).getItemMenu().getId() == itemMenu.getId()) {
					reportErroMensage("Item já adicionado anteriomente");
					return;
				}
			}

		}

		itemProduct.setItemMenu(itemMenu);
		itemProduct.setPrice(Tools.priceItem(itemProduct.getAmount(), itemMenu.getPrice()));
		itemProducts.add(itemProduct);
		itemMenu = new ItemMenu();
		itemProduct = new ItemProduct();
		reportSuccessMensage("Item adionado!");

	}

	public void removeItemProduct() {
		itemProducts.remove(itemProduct);
	}

	public String onFlowProcess(FlowEvent event) {

		return event.getNewStep();

	}

	public String finallybuy() {
		try {

			client = clientService.findByLogin(loginClient);
			order.setItemProducts(itemProducts);

			Address address = client.getAddresses().get(client.getAddresses().size() - 1);

			if (!address.getNumber().equals(order.getDelivery().getAddress().getNumber())
					|| !address.getCity().equals(order.getDelivery().getAddress().getCity())) {

				order.getDelivery().getAddress().setId(null);
				client.getAddresses().add(order.getDelivery().getAddress());

			}

			Validator.validateBuy(client);
			order.setData(new Date());
			order.setTotalprice(Tools.priceAllItens(order.getItemProducts()));
			order.setData(new Date());
			order.getPayment().setData(order.getData());
			client.getOrders().add(order);

			clientService.save(client);
			reportSuccessMensage("Pedido Registrado");
			return this.cancelOrder();

		} catch (RestDeliveryException e) {
			reportErroMensage(e.getMessage());
			e.printStackTrace();
		}
		return null;

	}

	public Client getClient() {
		if (client == null) {
			try {
				client = clientService.findByLogin(loginClient);
				order.getDelivery().setAddress(client.getAddresses().get(client.getAddresses().size() - 1));

			} catch (RestDeliveryException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return client;
	}

	public void setClient(Client client) {
		this.client = client;
	}

	public PaymentType[] getTypePayment() {
		return PaymentType.values();
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public List<ItemProduct> getItemProducts() {
		return itemProducts;
	}

	public void setItemProducts(List<ItemProduct> itemProducts) {
		this.itemProducts = itemProducts;
	}

	public ItemProduct getItemProduct() {
		return itemProduct;
	}

	public void setItemProduct(ItemProduct itemProduct) {
		this.itemProduct = itemProduct;
	}

	public ItemMenu getItemMenu() {
		return itemMenu;
	}

	public void setItemMenu(ItemMenu itemMenu) {
		this.itemMenu = itemMenu;
	}

	public String getLoginClient() {
		return loginClient;
	}

	public void setLoginClient(String loginClient) {
		this.loginClient = loginClient;
	}

	public float getPriceAll() {
		priceAll = Tools.priceAllItens(itemProducts);
		return priceAll;
	}

	public void setPriceAll(float priceAll) {
		this.priceAll = priceAll;
	}

}
