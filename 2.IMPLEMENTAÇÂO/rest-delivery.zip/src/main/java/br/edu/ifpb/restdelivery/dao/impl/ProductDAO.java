package br.edu.ifpb.restdelivery.dao.impl;

import java.io.Serializable;
import java.util.List;

import com.uaihebert.uaicriteria.UaiCriteria;
import com.uaihebert.uaicriteria.UaiCriteriaFactory;

import br.edu.ifpb.restdelivery.entities.Product;
import br.edu.ifpb.restdelivery.util.FilterProducts;

public class ProductDAO extends ImplGenericDAO<Product, Long> implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public List<Product> filterProduct(FilterProducts filterProducts) {
		
		UaiCriteria<Product> uaiCriteria = createUaiCriteria(filterProducts);

		uaiCriteria.setFirstResult(filterProducts.getFirst());
		uaiCriteria.setMaxResults(filterProducts.getAmount());

		if (filterProducts.isAscendent() && filterProducts.getPropetyOrdened() != null) {
			uaiCriteria.orderByAsc(filterProducts.getPropetyOrdened());

		} else if (filterProducts.getPropetyOrdened() != null) {
			uaiCriteria.orderByDesc(filterProducts.getPropetyOrdened());
		}

		return uaiCriteria.getResultList();

	}

	public int countFilter(FilterProducts filter) {
		UaiCriteria<Product> uaiCriteria = createUaiCriteria(filter);
		
		return ((Number) uaiCriteria.countRegularCriteria()).intValue();

	}

	public UaiCriteria<Product> createUaiCriteria(FilterProducts filterProducts) {
		UaiCriteria<Product> uaiCriteria = UaiCriteriaFactory.createQueryCriteria(em, Product.class);

		/*if (filterProducts.getDescription() != null || !filterProducts.getDescription().isEmpty()) {
			uaiCriteria.andEquals("id", filterProducts.getDescription());
		}
*/
		return uaiCriteria;
	}

}
