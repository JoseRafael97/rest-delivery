package br.edu.ifpb.restdelivery.controller;

import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

import br.edu.ifpb.restdelivery.entities.Order;
import br.edu.ifpb.restdelivery.services.impl.OrderService;

@Named
@RequestScoped
public class ListOrderBean extends AbstractBean {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Inject
	private OrderService orderService;

	private List<Order> orders;

	public List<Order> getOrders() {
		if (orders == null ) {
			orders = orderService.listAll();
		}
		return orders;
	}

	public void setOrders(List<Order> orders) {
		this.orders = orders;
	}

}
