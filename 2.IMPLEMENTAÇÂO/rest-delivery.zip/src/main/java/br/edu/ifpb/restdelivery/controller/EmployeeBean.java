package br.edu.ifpb.restdelivery.controller;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import br.edu.ifpb.restdelivery.entities.Employee;
import br.edu.ifpb.restdelivery.exceptions.RestDeliveryException;
import br.edu.ifpb.restdelivery.services.impl.EmployeeService;

@Named
@ViewScoped
public class EmployeeBean extends AbstractBean{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Inject
	private EmployeeService employeeService;
	
	private Employee employee;
	
	public void preRenderView() {
		if (employee == null) {
			employee = new Employee();
		}
	}
	
	public void save(){
		try {
			employeeService.save(employee);
			reportSuccessMensage("Funcionário criado/Alterado");
		} catch (RestDeliveryException e) {
			reportErroMensage(e.getMessage());
			e.printStackTrace();
		}
	}
	
	public void remove(){
		try {
			employeeService.remove(employee);
			reportSuccessMensage("Funcionário removido!");
		} catch (RestDeliveryException e) {
			reportErroMensage(e.getMessage());
			e.printStackTrace();
		}
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	
	

}
