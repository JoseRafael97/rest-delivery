package br.edu.ifpb.restdelivery.exceptions;

public class ItemExistenteException extends RestDeliveryException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ItemExistenteException(String mensagem) {
		super(mensagem);
		// TODO Auto-generated constructor stub
	}

}
