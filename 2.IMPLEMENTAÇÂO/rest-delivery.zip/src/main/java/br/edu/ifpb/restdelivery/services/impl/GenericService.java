package br.edu.ifpb.restdelivery.services.impl;

import java.io.Serializable;
import java.util.List;

import br.edu.ifpb.restdelivery.dao.impl.ImplGenericDAO;
import br.edu.ifpb.restdelivery.exceptions.RestDeliveryException;
import br.edu.ifpb.restdelivery.services.IFGenericService;
import br.edu.ifpb.restdelivery.util.jpa.Transactional;

public class GenericService<T, K extends Serializable> implements IFGenericService<T, K>, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected ImplGenericDAO<T, K> dao;

	@Transactional
	public void save(T obj) throws RestDeliveryException {
		dao.add(obj);
	}

	@Override
	@Transactional
	public void update(T obj) throws RestDeliveryException {
		dao.update(obj);
	}

	@Override
	@Transactional
	public void remove(T obj) throws RestDeliveryException {
		dao.remove(obj);
	}

	@Override
	public T find(K id) throws RestDeliveryException {
		return dao.find(id);
	}

	@Override
	public List<T> listAll() {
		return dao.findAll();
	}

}
