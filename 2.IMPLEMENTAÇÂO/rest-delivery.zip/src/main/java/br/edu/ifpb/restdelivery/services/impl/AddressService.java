package br.edu.ifpb.restdelivery.services.impl;

import java.util.List;

import javax.inject.Inject;

import br.edu.ifpb.restdelivery.dao.impl.AddressDAO;
import br.edu.ifpb.restdelivery.entities.Address;

public class AddressService extends GenericService<Address, Long>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Inject
	public AddressService(AddressDAO addressDAO) {
		this.dao = addressDAO;
	}
	
	public List<String> loadingCity(int idState){
		return ((AddressDAO)this.dao).loadingCity(idState);
	}
	
	

}
