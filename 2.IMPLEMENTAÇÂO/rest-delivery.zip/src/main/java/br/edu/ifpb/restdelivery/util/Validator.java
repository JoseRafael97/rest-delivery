package br.edu.ifpb.restdelivery.util;

import java.util.ArrayList;
import java.util.List;

import br.edu.ifpb.restdelivery.entities.Client;
import br.edu.ifpb.restdelivery.entities.Order;

public class Validator {
	
	public static void validateBuy(Client client){
		if(client.getOrders() == null) {
			List<Order> orders = new ArrayList<>();
			client.setOrders(orders);
		}
	}

}
