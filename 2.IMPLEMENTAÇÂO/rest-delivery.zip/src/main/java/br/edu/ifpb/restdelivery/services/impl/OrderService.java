package br.edu.ifpb.restdelivery.services.impl;

import javax.inject.Inject;

import br.edu.ifpb.restdelivery.dao.impl.OrderDAO;
import br.edu.ifpb.restdelivery.entities.Order;

public class OrderService extends GenericService<Order, Long>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	@Inject
	public OrderService(OrderDAO orderDAO) {
		this.dao = orderDAO;
	}

}
