package br.edu.ifpb.restdelivery.controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.event.AjaxBehaviorEvent;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import br.edu.ifpb.restdelivery.entities.Address;
import br.edu.ifpb.restdelivery.entities.Client;
import br.edu.ifpb.restdelivery.enumerations.StateNames;
import br.edu.ifpb.restdelivery.exceptions.RestDeliveryException;
import br.edu.ifpb.restdelivery.services.impl.AddressService;
import br.edu.ifpb.restdelivery.services.impl.ClientService;
import br.edu.ifpb.restdelivery.util.Tools;

@Named
@ViewScoped
public class ClientBean extends AbstractBean {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Client client;

	private List<String> listCity;

	@Inject
	private ClientService clientService;

	@Inject
	private AddressService addressService;

	private Address address;

	@PostConstruct
	void init() {
		if (client == null) {
			client = new Client();
		}

		if (address == null) {
			address = new Address();
		}
	}

	public void subjectSelectionChanged(final AjaxBehaviorEvent event) {
		listCity = addressService.loadingCity(Tools.getIdState(address.getState()));
	}

	public List<String> getLoadingCity() {

		if (listCity == null) {
			if (address.getState() != null) {
				listCity = addressService.loadingCity(Tools.getIdState(address.getState()));
			}else{
				listCity = new ArrayList<>();
			}
		}

		return listCity;
	}

	public StateNames[] getStateName() {
		StateNames[] states = StateNames.values();
		return states;
	}

	public void save() {
		try {
			if (address.getZipCode() != null) {

				if (client.getAddresses() == null) {
					client.setAddresses(new ArrayList<>());
				}

				client.getAddresses().add(address);

			}

			clientService.save(client);
			client = new Client();
			address = new Address();

			if (client.getId() == null) {
				reportSuccessMensage("Conta criada!");

			} else {
				reportSuccessMensage("Conta atualizada!");
			}
		} catch (RestDeliveryException e) {
			reportErroMensage("Erro ao salvar");
			e.printStackTrace();
		}
	}

	public Client getClient() {
		return client;
	}

	public void setClient(Client client) {
		this.client = client;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

}
