package br.edu.ifpb.restdelivery.exceptions;



public class PersistenceException extends RestDeliveryException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1780243892137781599L;

	public PersistenceException(String mensagem) {
		super(mensagem);
	}

	public PersistenceException(String mensagem, Throwable throwable) {
		super(mensagem, throwable);
	}

}
